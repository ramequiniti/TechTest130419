﻿namespace TimeUnit
{
    internal class SECONDS
    {
    }
}