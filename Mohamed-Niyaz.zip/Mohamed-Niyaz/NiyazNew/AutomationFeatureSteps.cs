﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TechTalk.SpecFlow;

namespace NiyazNew
{
    [Binding]
    class AutomationFeatureSteps
    {
        IWebDriver driver = new ChromeDriver();

      

        [Given(@"I open the Test webpage")]
        public void GivenIOpenTheTestWebpage(Table table)
        {
            var url = table.Rows;                     
            driver.Navigate().GoToUrl(url[0]["Url"]);
        }

        [When(@"I click on Sign in Link at the header")]
        public void WhenIClickOnSignInLinkAtTheHeader()
        {
            driver.FindElement(By.XPath("//a[@class='login']")).Click();
        }

        [When(@"I click on Create an Account button")]
        public void WhenIClickOnCreateAnAccountButton()
        {
            driver.FindElement(By.XPath("//button[@id='SubmitCreate']   ")).Click();

        }

        [When(@"I enter my email address in the email address field")]
        public void WhenIEnterMyEmailAddressInTheEmailAddressField(Table table)
        {
            var emailAddress = table.Rows;            
            driver.FindElement(By.XPath("//input[@name='email_create']")).SendKeys(emailAddress[0]["emailAddress"]);
        }

        [When(@"I enter my below personal details in the registration form")]
        public void WhenIEnterMyBelowPersonalDetailsInTheRegistrationForm(Table table)
        {

            var gender = table.Rows;
            var fName = table.Rows;
            var lName = table.Rows;
            string title = gender[0]["title"];
            if (title == "Male")            
                driver.FindElement(By.XPath("//input[@id='id_gender1']")).Click();
            else
                driver.FindElement(By.XPath("//input[@id='id_gender2']")).Click();            
            driver.FindElement(By.XPath("//input[@id='customer_firstname']")).SendKeys(fName[0]["firstName"]);
           
            driver.FindElement(By.XPath("//input[@id='customer_lastname']")).SendKeys(lName[0]["lastName"]);

            var address = table.Rows;
            driver.FindElement(By.XPath("//input[@id='address1']")).SendKeys(address[0]["address"]);

            var city = table.Rows;
            driver.FindElement(By.XPath("//input[@id='city']")).SendKeys(city[0]["city"]);

            var state = table.Rows;
            IWebElement element = driver.FindElement(By.Id("id_state"));
            SelectElement oSelect = new SelectElement(element);
            oSelect.SelectByText(state[0]["state"]);

            var mobile = table.Rows;
            driver.FindElement(By.XPath("phone_mobile")).SendKeys(mobile[0]["mobile"]);

            var zip = table.Rows;
            driver.FindElement(By.XPath("postcode")).SendKeys(city[0]["zip"]);

            var country = table.Rows;
            IWebElement element1 = driver.FindElement(By.Id("id_country"));
            SelectElement oSelect1 = new SelectElement(element1);
            oSelect1.SelectByText(state[0]["country"]);
        }

        [When(@"I click on Register button")]
        public void WhenIClickOnRegisterButton()
        {
            driver.FindElement(By.XPath("//button[@id='submitAccount']")).Click();
        }

        [When(@"I click on WishList button")]
        public void WhenIClickOnWishListButton()
        {
            driver.FindElement(By.XPath("//i[@class='icon-heart']/following-sibling::*[1]")).Click();
        }

        [Then(@"the page redirected to My account page")]
        public void ThenThePageRedirectedToMyAccountPage()
        {
            string expUrl = http://automationpractice.com/index.php?controller=my-account;
            String accountPageUrl = this.driver.Url;
            //Assert.E(accountPageUrl);   
            Assert.Equals(accountPageUrl, expUrl)         
        }

        [Then(@"My name (.*) displaying in the top right corner")]
        public void ThenMyNameDisplayingInTheTopRightCorner(string displayName)
        {

            string name = driver.FindElement(By.XPath("//a[@class='account']/span)")).Text;
            Assert.Equals(name, displayName);
        }

      

        [Then(@"I see the top sellers list in the my wishlist window")]
        public void ThenISeeTheTopSellersListInTheMyWishlistWindow()
        {
            string text = driver.FindElement(By.XPath("//a[@title = 'View a top sellers products']")).Text;
            Assert.Equals(text, "TOP SELLERS");
        }
    }
}
