package Automation.automation;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
   features = {"classpath:com/equiniti/feature/CustomerShopping.feature"},
   glue = {"Automation.automation"},
   tags={"@CutomerResgistration, @AddItem"}
)
public class AppTest {

}
