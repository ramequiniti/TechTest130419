package com.equiniti.enums;

public class SelectorEnums {

	public enum Selectors {
		id,xpath,name,linktext,partiallinktext,classname,css,tagname
	}

}
