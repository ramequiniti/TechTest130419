package com.equiniti.locators;

public interface Locators {

	//home page
	String lnk_ap_signIn = "xpath=//a[contains(text(),'Sign in')]";
	String frame_ap_createAccount = "xpath=//*[text()='Create an account']";
	String btn_ap_submitCreate = "id=SubmitCreate";
	String txt_email_create = "id=email_create";
	
	//Registration Page
	String frame_ap_personal_info = "xpath=//*[text()='Your personal information']";
	String radio_id_gender1 = "id=id_gender1";
	String radio_id_gender2 = "id=id_gender2";
	String txt_cust_firstName = "id=customer_firstname";
	String txt_cust_lastName = "id=customer_lastname";
	String txt_cust_password = "id=passwd";
	String cbo_dob_days = "id=days";
	String cbo_dob_months = "id=months";
	String cbo_dob_years = "id=years";
	String txt_cust_addr_firstName = "id=firstname";
	String txt_cust_addr_lastname = "id=lastname";
	String txt_cust_addr = "id=address1";
	String txt_cust_addr_city = "id=city";
	String cbo_cust_addr_state = "id=id_state";
	String txt_cust_addr_postcode = "id=postcode";
	String cbo_cust_addr_country = "name=id_country";
	String txt_cust_addr_phone_mobile = "name=phone_mobile";
	String txt_cust_future_alias = "name=alias";
	String btn_submitAccount = "id=submitAccount";
	
	//Mhy Account page
	String frame_my_account = "xpath=//h1[text()='My account']";
	String lnk_signout = "xpath=//a[contains(text(),'Sign out') and @title='Log me out']";
	String loggedin_user_name="xpath=//a[@title='View my customer account']/span";
	
	String lnk_wishlist = "xpath=//span[text()='My wishlists']";
	String lnk_topSellers = "xpath=//a[text()='Top sellers']";
	String top_sellers_products="xpath=//ul[@class='block_content products-block']/li";
	String top_sellers_item_name = "xpath=//h1[@itemprop='name']";
	String lnk_add_to_wishlist_btn = "id=wishlist_button";
	String top_sellers_qty = "id=quantity_wanted";
	
	String fancy_close_btn = "xpath=//a[@title='Close']";
	String fancy_inner_text = "xpath=//p[@class='fancybox-error']";
	
	String lnk_my_wish_list_view = "xpath=//div[@id='block-history']/table/tbody/tr/td/a[contains(text(),'View')]";
	String prod_s_title = "id=s_title";
	String prod_input_Qty = "xpath=//div[@class='wishlist_product_detail']//input";
	
	
	
	
	
	
	
	
}
