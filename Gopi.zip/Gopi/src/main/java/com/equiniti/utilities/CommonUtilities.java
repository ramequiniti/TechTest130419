package com.equiniti.utilities;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

import com.equiniti.enums.SelectorEnums.Selectors;

public class CommonUtilities {
	public static String itemPropertyName;
	public static WebDriver seleniumService = null;
	public static String current_tittle = "";
	static WebElement webElement = null;
	static List<WebElement> webElements = null;
	public static String randomCommentText = "";
	public static String itemPropertyQty;

	public static WebDriver OpenBrowser(String browser, String url) {
		WebDriver objWebDriver = null;
		boolean blnActionflag = false;
		if (!url.isEmpty()) {
			String driverPath = System.getProperty("user.dir").toString() + "\\drivers\\";
			switch (browser.toLowerCase()) {
			case "ie":
				try {
					System.setProperty("webdriver.ie.driver", driverPath + "\\IEDriverServer.exe");
					DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
					caps.setCapability(InternetExplorerDriver.INITIAL_BROWSER_URL, url);
					objWebDriver = new InternetExplorerDriver(caps);
					blnActionflag = true;
					Thread.sleep(5000);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case "firefox":
				try {
					objWebDriver = new FirefoxDriver();
					objWebDriver.manage().window().maximize();
					objWebDriver.get(url);
					blnActionflag = true;
					Thread.sleep(5000);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			case "chrome":
				try {
					System.out.println("*******************");
					System.out.println("launching chrome browser");
					System.setProperty("webdriver.chrome.driver", driverPath + "\\chrome\\chromedriver.exe");
					DesiredCapabilities capabilities = DesiredCapabilities.chrome();
					ChromeOptions options = new ChromeOptions();
					options.addArguments("test-type");
					options.addArguments("--start-maximized");
					options.addArguments("disable-extensions");
					options.addArguments("disable-infobars");
					options.setExperimentalOption("useAutomationExtension", false);
					capabilities.setCapability(ChromeOptions.CAPABILITY, options);
					objWebDriver = new ChromeDriver(capabilities);
					objWebDriver.get(url);
					blnActionflag = true;
					Thread.sleep(5000);
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;
			}
			objWebDriver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			if (blnActionflag) {
				System.out.println(browser + " launched with url: " + url);
			} else {
				System.out.println(browser + " not launched with url: " + url);
			}
		}
		seleniumService = objWebDriver;
		current_tittle = seleniumService.getTitle();
		return objWebDriver;
	}

	public static void selectDropDownByValue(String locator, String dataValue, String desc) {
		boolean blnActionflag = false;
		try {
			webElement = getWebElement(locator);
			if (webElement != null) {
				Select select = new Select(webElement);
				select.selectByValue(dataValue);
				blnActionflag = true;
				if (blnActionflag) {
					System.out.println(desc + " should select - " + dataValue + " selected");
				} else {
					System.err.println(desc + " should select - " + dataValue + " not selected");
				}
			}
		} catch (Exception e) {
			System.out.println("Expected element not clicked");
		}
	}
	
	public static void selectDropDownByVisibleText(String locator, String dataValue, String desc) {
		boolean blnActionflag = false;
		System.out.println("gopi");
		try {
			webElement = getWebElement(locator);
			if (webElement != null) {
				Select select = new Select(webElement);
				select.selectByVisibleText(dataValue);
				blnActionflag = true;
				if (blnActionflag) {
					System.out.println(desc + " should select - " + dataValue + " selected");
				} else {
					System.err.println(desc + " should select - " + dataValue + " not selected");
				}
			}
		} catch (Exception e) {
			System.out.println("Expected element not clicked");
		}
	}


	public static By getSelector(String locator) {
		By by = null;
		try {
			String locType = locator.split("=")[0].toLowerCase();
			String locatorVal = locator.split("=")[1].toString();
			Selectors enums = Selectors.valueOf(locType);
			switch (enums) {
			case id:
				by = By.id(locatorVal);
				break;
			case xpath:
				locatorVal = locator.substring(6);
				by = By.xpath(locatorVal);
				break;
			case name:
				by = By.name(locatorVal);
				break;
			case linktext:
				by = By.linkText(locatorVal);
				break;
			case partiallinktext:
				by = By.partialLinkText(locatorVal);
				break;
			case classname:
				by = By.className(locatorVal);
				break;
			case css:
				by = By.cssSelector(locatorVal);
				break;
			case tagname:
				by = By.tagName(locatorVal);
				break;
			default:
				break;
			}
		} catch (Exception e) {
			System.err.println("Exception " + e.getMessage());
		}
		return by;
	}

	public static WebElement getWebElement(String locator) {
		By by = null;
		boolean blnActionflag = false;
		try {
			by = getSelector(locator);
			if (by != null) {
				webElement = seleniumService.findElement(by);
				blnActionflag = true;
			}
			if (blnActionflag == true) {
				return webElement;
			} else {
				return null;

			}
		} catch (NoSuchElementException objNoSuchElm) {
			System.err.println(locator + " Element not found");
		}
		return null;
	}
	
	public static List<WebElement> getWebElements(String locator) {
		By by = null;
		boolean blnActionflag = false;
		try {
			by = getSelector(locator);
			if (by != null) {
				webElements = seleniumService.findElements(by);
				blnActionflag = true;
			}
			if (blnActionflag == true) {
				return webElements;
			} else {
				return null;

			}
		} catch (NoSuchElementException objNoSuchElm) {
			System.err.println(locator + " Element not found");
		}
		return null;
	}

	public static void sendKeys(String locator, String dataValue, String textBoxName) {
		try {
			webElement = getWebElement(locator);
			if (webElement != null) {
				JavascriptExecutor executor = (JavascriptExecutor) seleniumService;
				executor.executeScript("arguments[0].click();", webElement);
				webElement.clear();
				webElement.sendKeys(dataValue);
				System.out.println(textBoxName + " - " + dataValue + " text entered");
			} else {
				System.err.println(textBoxName + " - " + dataValue + " not text entered");
			}
		} catch (Exception e) {
			System.err.println(textBoxName + " - " + dataValue + " not text entered ; Exception : " + e);
		}
	}

	public static void clickElement(String locator, String buttonName) {
		try {
			webElement = getWebElement(locator);
			if (webElement != null && webElement.isDisplayed()) {
				webElement.click();
				System.out.println(buttonName + " clicked");
			} else {
				System.err.println(buttonName + " not clicked");
			}
		} catch (Exception e) {
			System.err.println(buttonName + " not clicked : Exception : " + e);
		}
	}
	
	public static void clickElementUsingJsExecutor(String locator, String buttonName) {
		try {
			Actions actions = new Actions(seleniumService);			
			webElement = getWebElement(locator);
			actions.moveToElement(webElement);
			actions.click().build().perform();
			((JavascriptExecutor) seleniumService).executeScript("arguments[0].scrollIntoView(true);", webElement);
			if (webElement != null && webElement.isDisplayed()) {
				TimeUnit.SECONDS.sleep(3);
				((JavascriptExecutor) seleniumService).executeScript("arguments[0].click();", webElement);
				System.out.println(buttonName + " clicked");
			} else {
				System.err.println(buttonName + " not clicked");
			}
		} catch (Exception e) {
			System.err.println(buttonName + " not clicked : Exception : " + e);
		}
	}
	
	

	public static boolean isDisplayed(String locator, String elementName) {
		try {
			webElement = getWebElement(locator);
			if (webElement != null && webElement.isDisplayed()) {
				System.out.println(elementName + " is Displayed");
				return true;
			} else {
				System.err.println(elementName + " is not Displayed");
			}
		} catch (Exception e) {
			System.err.println(elementName + " is not Displayed: Exception : " + e);
		}
		return false;
	}

	public static String getText(String locator) {
		webElement = getWebElement(locator);
		if (webElement != null) {
			return webElement.getText().toString();
		}
		return "";
	}
}
