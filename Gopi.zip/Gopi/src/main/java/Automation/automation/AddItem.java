package Automation.automation;

import com.equiniti.locators.Locators;
import com.equiniti.utilities.CommonUtilities;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddItem implements Locators {

	@Given("^User logged In and taken into my account page$")
	public void verify_am_logged_in() throws Throwable {
		CommonUtilities.isDisplayed(frame_my_account, "My account page");
		CommonUtilities.isDisplayed(lnk_signout,
				"sign out button in my account page");
	}

	@And("^I can see my name in top right corner$")
	public void verify_logged_in_user_name() throws Throwable {
		CommonUtilities.isDisplayed(loggedin_user_name, "logged_in_user_name");
		System.out.println("Logged in user name = "
				+ CommonUtilities.getText(loggedin_user_name));
	}

	@And("^I can see MY WISHLISTS link$")
	public void verify_my_wish_list_available() throws Throwable {
		CommonUtilities.isDisplayed(lnk_wishlist, "my_wishlist");
	}

	@When("^I can click on MY WISHLISTS link$")
	public void click_on_my_wish_list_link() throws Throwable {
		CommonUtilities.clickElement(lnk_wishlist, "MY WISHLISTS link");
	}

	@And("^I can see TOP SELLERS list on left side panel$")
	public void verify_top_sellers_list_available() throws Throwable {
		CommonUtilities.isDisplayed(lnk_topSellers, "TOP SELLERS link");
	}

	@And("^I can click on (.*) item in TOP SELLERS list$")
	public void click_on_item_in_top_sellers_list(int item_to_click)
			throws Throwable {
		CommonUtilities.clickElement(top_sellers_products+"["+item_to_click+"]/a", "Top Sellers " + item_to_click+" item");
	}

	
	@And("^I can see the product details$")
	public void product_details_on_screen() throws Throwable {
		CommonUtilities.itemPropertyName = CommonUtilities.getText(top_sellers_item_name);
		CommonUtilities.itemPropertyQty = CommonUtilities.getWebElement(top_sellers_qty).getAttribute("value").toString();
	}
	
	@And("^I can see Add to wishlist under Add to cart button$")
	public void verify_Add_to_wishlist_available() throws Throwable {
		CommonUtilities.isDisplayed(lnk_add_to_wishlist_btn,
				"Add_to_wishlist button");
	}

	@And("^I can add an item to my wish list$")
	public void click_Add_to_wishlist() throws Throwable {
		CommonUtilities.clickElement(lnk_add_to_wishlist_btn,
				"Add_to_wishlist button");
	}

	@Then("^Verify the application confirmation$")
	public void verify_application_confirmation() throws Throwable {
		CommonUtilities.isDisplayed(fancy_inner_text,
				"Application Confirmation");
		String fancy_app_text = CommonUtilities.getText(fancy_inner_text)
				.toString();
		System.out
				.println("Application Confirmation text is " + fancy_app_text);
		CommonUtilities.clickElement(fancy_close_btn,
				"Closing the application confirmation");
	}
	
	@And("^Click on logged in user name in top right corner$")
	public void click_logged_in_user_name() throws Throwable {
		CommonUtilities.clickElementUsingJsExecutor(loggedin_user_name, "logged_in_user_name");
	}
	
	@Then("^Click on Sign out link$")
	public void click_sign_out() throws Throwable {
		CommonUtilities.clickElement(lnk_signout, "Sign out");
	}
	
	@And("^Verify item is added to my wish liston MY WISHLIST page$")
	public void verify_item_added_in_wish_lists() throws Throwable {
		
		//Click on View link in Direct Link column
		CommonUtilities.clickElementUsingJsExecutor(lnk_my_wish_list_view, "lnk_my_wish_list_view");
		
		String my_wish_list_view_product_text = CommonUtilities.getText(prod_s_title).toString();
		String my_wish_list_view_product_Qty = CommonUtilities.getWebElement(prod_input_Qty).getAttribute("value").toString();
		
		if(my_wish_list_view_product_text.contains(CommonUtilities.itemPropertyName)){
			System.out.println("My_wish_list_view_product_text is " + my_wish_list_view_product_text);
		}
		
		if(Integer.parseInt(my_wish_list_view_product_Qty.trim()) >= Integer.parseInt(CommonUtilities.itemPropertyQty.trim())){
			System.out.println("my_wish_list_view_product_Qty is added " + my_wish_list_view_product_Qty);
		}
		
	}

}
