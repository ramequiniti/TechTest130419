package Automation.automation;

import com.equiniti.locators.Locators;
import com.equiniti.utilities.CommonUtilities;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CustomerRegistration implements Locators {

	@Given("^that open the url (.*) in (.*) browser$")
	public void that_open_the_url_browser(String url, String browser)
			throws Throwable {
		CommonUtilities.OpenBrowser(browser, url);
	}

	@And("^Click on SignIn link on the home page$")
	public void click_on_sign_in_btn_on_home_page() throws Throwable {
		CommonUtilities.clickElement(lnk_ap_signIn, "Sign In button");
	}

	@When("^Verify Create an account page is displayed$")
	public void verify_create_account_page_is_displayed() throws Throwable {
		CommonUtilities.isDisplayed(frame_ap_createAccount,
				"create account page element");
	}

	@And("^Enter an (.*) in email address field$")
	public void enter_email_id(String email_id) throws Throwable {
		CommonUtilities.sendKeys(txt_email_create, email_id, "Email Id");
	}
	
	
	@And("^Click on Create an account button$")
	public void click_on_create_an_account_btn() throws Throwable {
		CommonUtilities.clickElement(btn_ap_submitCreate, "Create an account button");
	}
	
	@Then("^Verify Personal Information page is displayed$")
	public void verify_personal_info_page_is_displayed() throws Throwable {
		CommonUtilities.isDisplayed(frame_ap_personal_info,
				"personal information page element");
	}
	
	@When("^select the (.*) in gender field$")
	public void select_gender(String gender) throws Throwable {
		if(gender.equalsIgnoreCase("Mr.")){
			CommonUtilities.clickElement(radio_id_gender1, "Mr. radio button");
		}else{
			CommonUtilities.clickElement(radio_id_gender2, "Mrs. radio button");
		}
	}
	
	@And("^Enter (.*) in firstname personal field$")
	public void enter_personal_firstname(String firstname) throws Throwable {
		CommonUtilities.sendKeys(txt_cust_firstName, firstname, "firstname");
	}
	@And("^Enter (.*) in lastname personal field$")
	public void enter_personal_lastname(String lastname) throws Throwable {
		CommonUtilities.sendKeys(txt_cust_lastName, lastname, "lastname");
	}
	
	@And("^Enter (.*) in firstname address field$")
	public void enter_addr_firstname(String firstname) throws Throwable {
		CommonUtilities.sendKeys(txt_cust_addr_firstName, firstname, "firstname");
	}
	@And("^Enter (.*) in lastname address field$")
	public void enter_addr_lastname(String lastname) throws Throwable {
		CommonUtilities.sendKeys(txt_cust_addr_lastname, lastname, "lastname");
	}
	
	@And("^Enter (.*) in password field$")
	public void enter_addr_password(String password) throws Throwable {
		CommonUtilities.sendKeys(txt_cust_password, password, "password");
	}
	
	@And("^Select (.*) value in dob days dropdown$")
	public void select_value_in_dob_days_dropdown(String days) throws Throwable {
		CommonUtilities.selectDropDownByValue(cbo_dob_days, days, "DOB days");
	}
	@And("^Select (.*) value in dob months dropdown$")
	public void select_value_in_dob_months_dropdown(String months) throws Throwable {
		CommonUtilities.selectDropDownByValue(cbo_dob_months, months, "DOB months");
	}
	@And("^Select (.*) value in dob years dropdown$")
	public void select_value_in_dob_years_dropdown(String years) throws Throwable {
		CommonUtilities.selectDropDownByValue(cbo_dob_years, years, "DOB years");
	}
	
	
	@And("^Enter (.*) in address field$")
	public void enter_addres(String address) throws Throwable {
		CommonUtilities.sendKeys(txt_cust_addr, address, "address");
	}
	
	@And("^Enter (.*) in city field$")
	public void enter_city(String city) throws Throwable {
		CommonUtilities.sendKeys(txt_cust_addr_city, city, "city");
	}
	@And("^Select (.*) in state dropdown$")
	public void select_value_state_dropdown(String state) throws Throwable {
		CommonUtilities.selectDropDownByVisibleText(cbo_cust_addr_state, state, "state");
	}
	
	@And("^Enter (.*) in postal_code field$")
	public void enter_postal_code(String postal_code) throws Throwable {
		CommonUtilities.sendKeys(txt_cust_addr_postcode, postal_code, "postal_code");
	}
	
	@And("^Select (.*) in country dropdown$")
	public void select_value_country_dropdown(String country) throws Throwable {
		CommonUtilities.selectDropDownByVisibleText(cbo_cust_addr_country, country, "country");
	}
	
	@And("^Enter (.*) in mobile field$")
	public void enter_mobile(String mobile) throws Throwable {
		CommonUtilities.sendKeys(txt_cust_addr_phone_mobile, mobile, "mobile");
	}
	
	@And("^Enter (.*) in alias field$")
	public void enter_alias(String alias) throws Throwable {
		CommonUtilities.sendKeys(txt_cust_future_alias, alias, "alias");
	}
	
	@And("^Click on Register button on register page$")
	public void click_on_register_button() throws Throwable {
		CommonUtilities.clickElement(btn_submitAccount, "Register button");
	}
}
