﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.Extensions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using ClassLibrary1.Objects;
using ClassLibrary1.Common;
using System.Collections;
using MbUnit.Framework;
namespace ClassLibrary1.Tests
{
    /// <summary>
    /// Test class to add new customer and add item to wish list
    /// </summary>
    [MbUnit.Framework.TestFixture]
    class NewUser
    {
        public IWebDriver browser = null;

        [FixtureSetUp]
        public void Setup()
        {
            try
            {
                browser = new ChromeDriver();
                browser.Navigate().GoToUrl("http://automationpractice.com/index.php");
                browser.Manage().Timeouts().ImplicitWait = TimeSpan.FromMinutes(1);
                browser.Manage().Timeouts().PageLoad = TimeSpan.FromMinutes(1);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while creating browser instance : " + ex.Message);
            }
        }

        [MbUnit.Framework.Test]
        public void CreateNewCusomter()
        {
            try
            {
                ExcelData data = new ExcelData();
                Hashtable htTestData = data.GetRowValues();

                HomePage home = new HomePage(browser);  // initialise Page object class

               

                home.CreateNewAccount(htTestData); // create new Account

               
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while creating new cusomter : " + ex.Message);
            }
        }

        [FixtureTearDown]
        public void Cleanup()
        {
            try
            {
                browser.Close();
                browser.Quit();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while closing browser instance : " + ex.Message);
            }
        }
    }
}
