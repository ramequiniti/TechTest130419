package step_Definition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Registration_steps {

	public static WebDriver driver;
	
	/*@Before
	public static void intialization()
	{
		
	}*/

	@Given("^User is on sign page$")
	public void registration()
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/admin/Downloads/chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.get("http://automationpractice.com/index.php");
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);	
		
		driver.findElement(By.xpath("(//*[@id='heade']/div[2]//a)[1]")).click();
		System.out.println("on Create account page");
				
	}
	
	@When("^User enters email address as \"(.*)\" for registration$")
	public static void enters_EmailID(String strUserID)
	{
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
			
			driver.findElement(By.id("email_create")).sendKeys(strUserID);
			
			driver.findElement(By.xpath("//*[@id='SubmitCreate']/span/i")).click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Then("^User should be able to create an account successfully$")
	public static void Verify_Registration()
	{
		try {
			String page_title= driver.getTitle();
			
			if(page_title.equalsIgnoreCase("Login - My Store"))
			{
				System.out.println("Account Created");
			}
			else
			{
				System.out.println("Account not created ...try again");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Given("^User is on home page$")
	public static void OnHomepage()
	{
		String strPageTitle=driver.getTitle();
		
		if(strPageTitle.equalsIgnoreCase("My Account - My Store"))
		{
			System.out.println("In Account Page");
		}
	}
	@When("^User is on home page$")
	public static void account_Details()
	{
	
		try {
			driver.findElement(By.id("id_gender2")).click();
			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
			
			driver.findElement(By.id("customer_firstname")).sendKeys("XYZ_first");
			
			driver.findElement(By.id("customer_lastname")).sendKeys("XYZ_last");
			
			driver.findElement(By.id("passwd")).sendKeys("test_pwd");
			
			
			driver.findElement(By.id("address1")).sendKeys("Test Add1");
			
			driver.findElement(By.id("city")).sendKeys("Test_City");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
			
			WebElement state= driver.findElement(By.id("id_state"));
			
			Select sel_State= new Select(state);
			
			sel_State.selectByVisibleText("New York");
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
			
			driver.findElement(By.id("postcode")).sendKeys("60011");
			
			driver.findElement(By.id("phone_mobile")).sendKeys("1234567890");
			
			driver.findElement(By.id("alias")).sendKeys("Test Address");
			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
			
			driver.findElement(By.xpath("//*[@id='submitAccount']/span/text()")).click();
			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Then("^Then User should be able to navigate to the my account page$")
	public static void verifyPage_Nav()
	{
		
		try {
			Boolean registered=driver.findElement(By.xpath("//*[@id='header']/div[2]//div[1]/a/span")).isDisplayed();
			
			if(registered)
			{
				System.out.println("User registration successfully");
			}
			
			else
			{
				System.out.println("User registration unsucessfull");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
