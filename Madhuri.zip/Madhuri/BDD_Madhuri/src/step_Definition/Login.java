package step_Definition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Login {

	static WebDriver driver;
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:/Users/admin/Downloads/chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.get("http://automationpractice.com/index.php");
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
		
		
		
			
		
		
	}
	
	public static void account_creation()
	{
		driver.findElement(By.xpath("(//*[@id='heade']/div[2]//a)[1]")).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);
		
		driver.findElement(By.id("email_create")).sendKeys("xyz@email.com");
		
		driver.findElement(By.xpath("//*[@id='SubmitCreate']/span/i")).click();
	}
	
	public static void registration_details()
	{
		driver.findElement(By.id("id_gender2")).click();
		
		driver.findElement(By.id("customer_firstname")).sendKeys("XYZ_first");
		
		driver.findElement(By.id("customer_lastname")).sendKeys("XYZ_last");
		
		driver.findElement(By.id("passwd")).sendKeys("test_pwd");
		
		
		driver.findElement(By.id("address1")).sendKeys("Test Add1");
		
		driver.findElement(By.id("city")).sendKeys("Test_City");
		
		WebElement state= driver.findElement(By.id("id_state"));
		
		Select sel_State= new Select(state);
		
		sel_State.selectByVisibleText("New York");
		
		driver.findElement(By.id("postcode")).sendKeys("600119");
		
		driver.findElement(By.id("phone_mobile")).sendKeys("9884877840");
		
		driver.findElement(By.id("alias")).sendKeys("Test Address");
		
		driver.findElement(By.xpath("//*[@id='submitAccount']/span/text()")).click();
		
		Boolean registered=driver.findElement(By.xpath("//*[@id='header']/div[2]//div[1]/a/span")).isDisplayed();
		
		if(registered)
		{
			System.out.println("User registration successfully");
		}
		
		else
		{
			System.out.println("User registration unsucessfull");
		}
		
		driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[2]/a")).click();
	}
	
	public static void adding_item_to_wishlist()
	{
		driver.findElement(By.xpath("//*[@id='center_colum']/div/div[2]/ul/li/a/span")).click();
		
		driver.findElement(By.xpath("//*[@id='best-sellers_block_right']/div/ul/li[1]/div/h5/a")).click();
		
		driver.findElement(By.id("wishlist_button")).click();
		
		WebElement confirmation=driver.findElement(By.xpath("//*[@id='product']/div[2]/div/div/a"));
		
		if(confirmation.isDisplayed())
		{
			System.out.println("Item added to wishlist");
		}
		else
		{
			System.out.println("Item not added to wishlist");
		}
		
		driver.findElement(By.xpath("//*[@id='product']/div[2]/div/div/a")).click();
		
		
		
	}
	
	public static void confirm_Product()
	{
		driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a/span")).click();
		
		driver.findElement(By.xpath("//*[@id='center_colum']/div/div[2]/ul/li/a/span")).click();
		
		WebElement item=driver.findElement(By.xpath("//*[@id='wishlist_10028']/td[2]"));
		
		String strQuantity=item.getText();
		
		if(strQuantity.equalsIgnoreCase("1"))
		{
			System.out.println("Item present in wishlist");
		}
		
		else
		{
			System.out.println("Item Not present in wishlist");
		}
	}
}
