package step_Definition;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Add_Item_To_cart {
	
	public static WebDriver driver;
	@Given("^User is on myAccount page enters \"(.*)\" and \"(.*)\" $")
	public void signIn(String strUserId, String strPass)
	{
		System.setProperty("webdriver.chrome.driver", "C:/Users/admin/Downloads/chromedriver.exe");
		
		driver = new ChromeDriver();
		
		driver.get("http://automationpractice.com/index.php");
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);	
		
		driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a")).click();
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);	
		
		driver.findElement(By.id("email")).sendKeys(strUserId);
		driver.findElement(By.id("passwd")).sendKeys(strPass);
		driver.findElement(By.xpath("(//*[@id='SubmitLogin']/span/text())[1]")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.MILLISECONDS);	
		
		System.out.println("on  account page");
				
	}
	
	@When("^User adds items to wishlist$")
	public static void add_ItemsToWishlist(String strUserID)
	{
		try {
			driver.findElement(By.xpath("//*[@id='center_colum']/div/div[2]/ul/li/a/span")).click();
			
			driver.findElement(By.xpath("//*[@id='best-sellers_block_right']/div/ul/li[1]/div/h5/a")).click();
			
			driver.findElement(By.id("wishlist_button")).click();
			
			WebElement confirmation=driver.findElement(By.xpath("//*[@id='product']/div[2]/div/div/a"));
			
			if(confirmation.isDisplayed())
			{
				System.out.println("Item added to wishlist");
			}
			else
			{
				System.out.println("Item not added to wishlist");
			}
			
			driver.findElement(By.xpath("//*[@id='product']/div[2]/div/div/a")).click();
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Then("^User should be able to see the added item in wishlist$")
	public static void verify_wishList()
	{
		try {
			driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a/span")).click();
			
			driver.findElement(By.xpath("//*[@id='center_colum']/div/div[2]/ul/li/a/span")).click();
			
			WebElement item=driver.findElement(By.xpath("//*[@id='wishlist_10028']/td[2]"));
			
			String strQuantity=item.getText();
			
			if(strQuantity.equalsIgnoreCase("1"))
			{
				System.out.println("Item present in wishlist");
			}
			
			else
			{
				System.out.println("Item Not present in wishlist");
			}
		
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	

}
