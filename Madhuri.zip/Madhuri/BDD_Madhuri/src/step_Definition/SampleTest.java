package step_Definition;

public class SampleTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Test");

	}

}
