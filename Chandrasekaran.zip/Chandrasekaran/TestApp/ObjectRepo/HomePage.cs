﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.Extensions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using MbUnit.Framework;
using TestApp.Generic;
using System.Collections;

namespace TestApp.ObjectRepo
{
    class HomePage
    {
        public IWebDriver browser;
        string strEmailID = null, strPassword;

        public string strFirstName, strLastName, strAddress, strCity, strState, strPostalCode, strCountry, strMobileNo, strAddressAlias;

        [FindsBy(How = How.PartialLinkText, Using = "Sign in")]
        public IWebElement link_SignIn { get; set; }

        #region SignIn Page objects
            [FindsBy(How = How.XPath, Using = "//div[@id='center_column'//h1[contains(text(), 'Authentication')]]")]
            public IWebElement header_SignIn { get; set; }

            [FindsBy(How = How.Id, Using = "email_create")]
            public IWebElement txtbox_EmailAddress { get; set; }

            [FindsBy(How = How.Id, Using = "SubmitCreate")]
            public IWebElement button_CreateAnAccount { get; set; }

            [FindsBy(How = How.Id, Using = "create_account_error")]
            public IWebElement div_CreateAccountError { get; set; }
        #endregion SignIn Page objects

        #region Create An Account Page objects
            [FindsBy(How = How.XPath, Using = "//div[@id='center_column'//h1[contains(text(), 'Create an account')]]")]
            public IWebElement header_CreateAccount { get; set; }

            [FindsBy(How = How.Id, Using = "uniform-id_gender1")]
            public IWebElement radio_Mr { get; set; }

            [FindsBy(How = How.Id, Using = "uniform-id_gender2")]
            public IWebElement radio_Mrs { get; set; }

            [FindsBy(How = How.Id, Using = "customer_firstname")]
            public IWebElement txtbox_FirstName { get; set; }

            [FindsBy(How = How.Id, Using = "customer_lastname")]
            public IWebElement txtbox_LastName { get; set; }

            [FindsBy(How = How.Id, Using = "email")]
            public IWebElement txtbox_EmailID { get; set; }

            [FindsBy(How = How.Id, Using = "passwd")]
            public IWebElement txtbox_Password { get; set; }

            [FindsBy(How = How.Id, Using = "days")]
            public IWebElement select_Day { get; set; }

            [FindsBy(How = How.Id, Using = "months")]
            public IWebElement select_Month { get; set; }

            [FindsBy(How = How.Id, Using = "years")]
            public IWebElement select_Year { get; set; }

            [FindsBy(How = How.Id, Using = "firstname")]
            public IWebElement txtbox_CustomerFirstName { get; set; }

            [FindsBy(How = How.Id, Using = "lastname")]
            public IWebElement txtbox_CustomerLastName { get; set; }

            [FindsBy(How = How.Id, Using = "company")]
            public IWebElement txtbox_Company { get; set; }

            [FindsBy(How = How.Id, Using = "address1")]
            public IWebElement txtbox_AddressLine1 { get; set; }

            [FindsBy(How = How.Id, Using = "city")]
            public IWebElement txtbox_City { get; set; }

            [FindsBy(How = How.Id, Using = "id_state")]
            public IWebElement select_State { get; set; }

            [FindsBy(How = How.Id, Using = "postcode")]
            public IWebElement txtbox_PostCode { get; set; }

            [FindsBy(How = How.Id, Using = "id_country")]
            public IWebElement select_Country { get; set; }

            [FindsBy(How = How.Id, Using = "phone_mobile")]
            public IWebElement txtbox_MobilePhone { get; set; }

            [FindsBy(How = How.Id, Using = "alias")]
            public IWebElement txtbox_AddressAlias { get; set; }

            [FindsBy(How = How.Id, Using = "submitAccount")]
            public IWebElement button_Register { get; set; }
        #endregion Create An Account Page objects

        #region Login dashboard Page objects
            [FindsBy(How = How.XPath, Using = "//a[@href='http://automationpractice.com/index.php?controller=my-account']")]
            public IWebElement link_UserName { get; set; }

            [FindsBy(How = How.PartialLinkText, Using = "Sign out")]
            public IWebElement link_SignOut { get; set; }

            [FindsBy(How = How.XPath, Using = "//div[@id='center_column'//h1[contains(text(), 'My account')]]")]
            public IWebElement header_MyAccount { get; set; }

            [FindsBy(How = How.PartialLinkText, Using = "My wishlists")]
            public IWebElement link_MyWishList { get; set; }
        #endregion Login dashboard Page objects

        #region WishList Page objects
            [FindsBy(How = How.XPath, Using = "//div[@id='mywishlist'//h1[contains(text(), 'My wishlists')]]")]
            public IWebElement header_MyWishList { get; set; }

            [FindsBy(How = How.PartialLinkText, Using = "Top sellers")]
            public IWebElement link_TopSellers { get; set; }

            [FindsBy(How = How.Id, Using = "wishlist_button")]
            public IWebElement link_AddToWishList { get; set; }

            [FindsBy(How = How.ClassName, Using = "fancybox-overlay fancybox-overlay-fixed")]
            public IWebElement div_WishListPopup { get; set; }

            [FindsBy(How = How.ClassName, Using = "fancybox-item fancybox-close")]
            public IWebElement link_WishListPopupClose { get; set; }

            [FindsBy(How = How.Id, Using = "block-history")]
            public IWebElement div_History{ get; set; }
        #endregion WishList Page objects

        public HomePage(IWebDriver browser)
        {
            this.browser = browser;
            PageFactory.InitElements(browser, this);
        }
        public void NavigateToSiginPage()
        {
            try
            {
                link_SignIn.Click();
                PageEvents.WaitForPageLoad(this.browser);

                if (header_SignIn.Displayed)
                    Console.WriteLine("Successfully navigated to Signin page");
                else
                    throw new Exception("'Authentication' header text is not found or displayed");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while navigating to SignIn page : " + ex.Message);
            }
        }

        public void CreateNewAccount(Hashtable htData)
        {
            try
            {
                NavigateToSiginPage();

                foreach (DictionaryEntry data in htData) // iterate for each test data
                {
                    if (data.Key.ToString() == "FirstName")
                        strFirstName = data.Value.ToString();
                    if (data.Key.ToString() == "LastName")
                        strLastName = data.Value.ToString();
                    if (data.Key.ToString() == "Address")
                        strAddress = data.Value.ToString();
                    if (data.Key.ToString() == "City")
                        strCity = data.Value.ToString();
                    if (data.Key.ToString() == "State")
                        strState = data.Value.ToString();
                    if (data.Key.ToString() == "PostalCode")
                        strPostalCode = data.Value.ToString();
                    if (data.Key.ToString() == "Country")
                        strCountry = data.Value.ToString();
                    if (data.Key.ToString() == "MobileNo")
                        strMobileNo = data.Value.ToString();
                    if (data.Key.ToString() == "AddressAlias")
                        strAddressAlias = data.Value.ToString();
                    if (data.Key.ToString() == "strEmailID")
                        strEmailID = data.Value.ToString();
                    if (data.Key.ToString() == "Password")
                        strPassword = data.Value.ToString();

                    txtbox_EmailAddress.SendKeys(strEmailID);
                    button_CreateAnAccount.Click();
                    PageEvents.WaitForPageLoad(this.browser);

                    if (div_CreateAccountError.Displayed)
                        throw new Exception("Input validation error has been throw : " + div_CreateAccountError.Text);

                    if (header_CreateAccount.Displayed)
                        Console.WriteLine("Create Account page displayed successfully");
                    else
                        throw new Exception("'CREATE AN ACCOUNT' header is not displayed or not found");

                    // Enter personal details
                    radio_Mr.Click();
                    txtbox_FirstName.SendKeys(strFirstName);
                    txtbox_LastName.SendKeys(strLastName);

                    Assert.AreEqual(txtbox_EmailID.Text, strEmailID, "The entered email id '" + strEmailID + "' is not preserved in Emaild ID textbox");
                    Console.WriteLine("The entered Email ID is preserved '" + strEmailID + "'");
                    //if (txtbox_EmailID.Text.Contains(strEmailID))
                    //    Console.WriteLine("The entered Email ID is preserved '" + strEmailID + "'");
                    //else
                    //    throw new Exception("The entered email id '" + strEmailID + "' is not preserved in Emaild ID textbox");

                    txtbox_Password.SendKeys(strPassword);

                    SelectElement select = new SelectElement(select_Day);
                    select.SelectByValue("28");
                    select = new SelectElement(select_Month);
                    select.SelectByText("March");
                    select = new SelectElement(select_Year);
                    select.SelectByValue("1990");

                    //txtbox_CustomerFirstName.SendKeys("FirstName"); // check if the entered data are updated in these fields
                    //txtbox_CustomerLastName.SendKeys("LastName");
                    Assert.AreEqual(txtbox_CustomerFirstName.Text, strFirstName, "First Name field value not retained");
                    Assert.AreEqual(txtbox_CustomerLastName.Text, strLastName, "Last Name field value not retained");

                    txtbox_Company.SendKeys("Aspire Systems");
                    txtbox_AddressLine1.SendKeys(strAddress);
                    txtbox_City.SendKeys(strCity);

                    select = new SelectElement(select_State);
                    select.SelectByText(strState);

                    txtbox_PostCode.SendKeys(strPostalCode);

                    select = new SelectElement(select_Country);
                    select.SelectByText(strCountry);

                    txtbox_MobilePhone.SendKeys(strMobileNo);
                    txtbox_AddressAlias.SendKeys(strAddressAlias);

                    button_Register.Click();
                    PageEvents.WaitForPageLoad(browser);

                    CheckVerificationPoints();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while creating new Account : " + ex.Message);
            }
        }

        public void CheckVerificationPoints()
        {
            try
            {
                DefaultWait<IWebElement> wait = new DefaultWait<IWebElement>(header_MyAccount);
                wait.Timeout = TimeSpan.FromMinutes(1);

                // check My Account label is displayed
                if (header_MyAccount.Displayed)
                    Console.WriteLine("'My Account' header page is displayed");
                else
                    throw new Exception("'My Account' header page is displayed or not found");

                // check User Name label is displayed
                if (link_UserName.Displayed && link_UserName.Text.Contains(strFirstName + " " + strLastName))
                    Console.WriteLine("The logged in user name is displayed in dashboard page");
                else
                    throw new Exception("The logged in user name is not displayed in dashboard page");

                // check Signout link is displayed
                if (link_SignOut.Displayed)
                    Console.WriteLine("'Sign Out' link is displayed");
                else
                    throw new Exception("'Sign Out' link is not displayed");

                // check My WishList link is displayed
                if (link_MyWishList.Displayed)
                    Console.WriteLine("'My WishList' link is displayed");
                else
                    throw new Exception("'My WishList' link is not displayed");

                // click My WishList
                link_MyWishList.Click();
                PageEvents.WaitForPageLoad(browser);

                // check My WishList label is displayed post selecting My WishList link
                wait = new DefaultWait<IWebElement>(header_MyWishList);
                wait.Timeout = TimeSpan.FromMinutes(1);
                if (header_MyWishList.Displayed)
                    Console.WriteLine("'My WishList' header page is displayed");
                else
                    throw new Exception("'My WishList' header page is not displayed or not found");

                // check If any Top sellers are available
                if (link_TopSellers.Displayed)
                    Console.WriteLine("'Top Sellers' link is displayed");
                else
                    throw new Exception("'Top Sellers' link is not displayed or not found");

                // select the First Top seller
                IWebElement div_TopSeller = browser.FindElement(By.Id("left_column"));
                IWebElement list_FirstTopSeller = div_TopSeller.FindElement(By.XPath("//li[1]"));
                IWebElement list_FirstProduct = list_FirstTopSeller.FindElement(By.XPath("//a[@class='product-name']"));
                string strFirstProductname = list_FirstProduct.Text;
                list_FirstProduct.Click();
                PageEvents.WaitForPageLoad(browser);

                // check if the Add To WishList link is displayed in product description page
                wait = new DefaultWait<IWebElement>(link_AddToWishList);
                wait.Timeout = TimeSpan.FromMinutes(1);
                if (link_AddToWishList.Displayed)
                    Console.WriteLine("'Add To WishList' header page is displayed");
                else
                    throw new Exception("'Add To WishList' header page is not displayed or not found");

                // Add the product the WishList
                link_AddToWishList.Click();
                PageEvents.WaitForPageLoad(browser);
                                
                // Check for the confirmation popup
                wait = new DefaultWait<IWebElement>(div_WishListPopup);
                wait.Timeout = TimeSpan.FromMinutes(1);
                if (div_WishListPopup.Displayed)
                {
                    Console.WriteLine("'Add To WishList' confirmation popup is displayed");
                    link_WishListPopupClose.Click(); // close the popup
                }
                else
                    throw new Exception("'Add To WishList' confirmation popup is not displayed or not found");

                // Navigate to dashboard
                link_UserName.Click();
                PageEvents.WaitForPageLoad(browser);

                // check My WishList link is displayed
                if (link_MyWishList.Displayed)
                    Console.WriteLine("'My WishList' link is displayed");
                else
                    throw new Exception("'My WishList' link is not displayed");

                // click My WishList
                link_MyWishList.Click();
                PageEvents.WaitForPageLoad(browser);

                // check My WishList label is displayed post selecting My WishList link
                wait = new DefaultWait<IWebElement>(header_MyWishList);
                wait.Timeout = TimeSpan.FromMinutes(1);
                if (header_MyWishList.Displayed)
                    Console.WriteLine("'My WishList' header page is displayed");
                else
                    throw new Exception("'My WishList' header page is not displayed or not found");

                // check if the added item is listed in My WishList table
                if (div_History.Displayed)
                    Console.WriteLine("WishList table container is displayed");
                else
                    throw new Exception("WishList table container is not displayed or not found");

                div_History.FindElement(By.XPath(".//a[contains(text(), 'My wishlist')]")).Click();
                IWebElement div_WLDetails = browser.FindElement(By.XPath(".//div[@class='wlp_bought']"));
                IWebElement para_ProductName = div_WLDetails.FindElement(By.Id("s_title"));
                Assert.AreEqual(para_ProductName.Text.Trim(), strFirstProductname, "The added item '" + strFirstProductname + "' not found in list");

                IWebElement txtbox_Quantity = browser.FindElement(By.XPath(".//input[contains(@id, 'quantity')]"));
                if (txtbox_Quantity.Text.Trim() == "1")
                    Console.WriteLine("The respective quantity is added");
                else
                    throw new Exception("The respective quantity is not added correctly");
                //Assert.Count(1, txtbox_Quantity.Text.Trim(), "The respective quantity is not added correctly");                
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while checking verification points : " + ex.Message);
            }
        }
    }
}
