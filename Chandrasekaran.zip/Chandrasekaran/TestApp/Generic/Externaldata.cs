﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;
using System.Collections;

namespace TestApp.Generic
{
    public class Externaldata
    {
        enum enumColumnIndex
        {
            FirstName = 0,
            LastName = 1,
            Address = 2,
            City = 3,
            State = 4,
            PostalCode = 5,
            Country= 6,
            MobileNo = 7,
            AddressAlias = 8,
            EmailID = 9,
            Password = 10
        }

        Excel.Application xlApp = null;
        Excel.Workbook xlWorkBook = null;
        Excel.Worksheet xlWorkSheet = null;
        Excel.Range xlRange = null;
        public Externaldata()
        {
            xlApp = new Excel.Application();
            xlWorkBook = xlApp.Workbooks.Open(@"E:\Chan_Test\TestApp\TestData.xlsx");
            xlWorkSheet = xlWorkBook.Worksheets["TestData"];
            xlRange = xlWorkSheet.UsedRange;
        }

        public Hashtable GetRowValues()
        {
            Hashtable htTestData = new Hashtable();
            for (int intRow = 0; intRow < xlRange.Rows.Count; intRow++)
            {

                htTestData.Add("FirstName", xlRange.Cells[intRow][enumColumnIndex.FirstName]);
                htTestData.Add("LastName", xlRange.Cells[intRow][enumColumnIndex.LastName]);
                htTestData.Add("Address", xlRange.Cells[intRow][enumColumnIndex.Address]);
                htTestData.Add("City", xlRange.Cells[intRow][enumColumnIndex.City]);
                htTestData.Add("State", xlRange.Cells[intRow][enumColumnIndex.State]);
                htTestData.Add("PostalCode", xlRange.Cells[intRow][enumColumnIndex.PostalCode]);
                htTestData.Add("Country", xlRange.Cells[intRow][enumColumnIndex.Country]);
                htTestData.Add("MobileNo", xlRange.Cells[intRow][enumColumnIndex.MobileNo]);
                htTestData.Add("AddressAlias", xlRange.Cells[intRow][enumColumnIndex.AddressAlias]);
                htTestData.Add("EmailID", xlRange.Cells[intRow][enumColumnIndex.EmailID]);
                htTestData.Add("Password", xlRange.Cells[intRow][enumColumnIndex.Password]);
            }
            return htTestData;
        }

        ~Externaldata()
        {           
            xlWorkBook.Close();
            xlApp.Quit();
        }
    }
}
