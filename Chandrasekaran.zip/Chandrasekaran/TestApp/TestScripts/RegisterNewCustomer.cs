﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MbUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.Extensions;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using TestApp.ObjectRepo;
using TestApp.Generic;
using System.Collections;

namespace TestApp.TestScripts
{
    /// <summary>
    /// Test class to register new customer and add itm to wish list
    /// </summary>
    [TestFixture]
    class RegisterNewCustomer
    {
        public IWebDriver browser = null;

        [FixtureSetUp]
        public void Setup()
        {
            try
            {
                browser = new ChromeDriver();
                browser.Navigate().GoToUrl("http://automationpractice.com/index.php");
                browser.Manage().Timeouts().ImplicitWait = TimeSpan.FromMinutes(1);
                browser.Manage().Timeouts().PageLoad = TimeSpan.FromMinutes(1);
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error while creating browser instance : " + ex.Message);
            }
        }

        [Test]
        public void CreateNewCusomter()
        {
            try
            {
                Externaldata data = new Externaldata();
                Hashtable htTestData = data.GetRowValues();

                HomePage home = new HomePage(browser);  // initialise Page object class

                // home.NavigateToSiginPage(); // open SigIn page -- commented as called in CreateNewAccount() below

                home.CreateNewAccount(htTestData); // create new Account

                // home.CheckVerificationPoints(); // check the verification points -- commented as called in CreateNewAccount() above
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while creating new cusomter : " + ex.Message);
            }
        }

        [FixtureTearDown]
        public void Cleanup()
        {
            try
            {
                browser.Close();
                browser.Quit();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error while closing browser instance : " + ex.Message);
            }
        }
    }
}
