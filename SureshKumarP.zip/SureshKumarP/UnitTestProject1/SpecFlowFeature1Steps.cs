﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using TechTalk.SpecFlow;

namespace UnitTestProject1
{
    [Binding]
    public class SpecFlowFeature1Steps
    {
        IWebDriver driver = new ChromeDriver(@"C:\Users\Admin\Downloads\chromedriver_win32");
        

        [Given(@"I launch the browser and load '(.*)'")]
        public void GivenILaunchTheBrowserAndLoad(string url)
        {
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            driver.Navigate().GoToUrl(url);
        }

        [Given(@"I click signin button")]
        public void GivenIClickSigninButton()
        {
            driver.FindElement(By.XPath("//a[@class = 'login']")).Click();
        }

        [When(@"I Click Register button")]
        public void ThenIClicRegisterButton()
        {
            driver.FindElement(By.XPath("//button[@id='submitAccount']")).Click();
        }

        [Then(@"I can see my name at top right corner (.*)")]
        public void ThenICanSeeMyNameAtTopRightCorner(string name)
        {
            try {
                IWebElement element = driver.FindElement(By.XPath("//button[@id='submitAccount']"));
                if (!element.Text.Contains(name))
                    Assert.Fail();
            }
            catch (Exception e)
            {
                
            }
            
           
            
        }

        [When(@"I can see My WishList link and able to click")]
        public void ThenICanSeeMyWishListLink()
        {
            try
            {
                IWebElement element = driver.FindElement(By.XPath("//button[@id='submitAccount']"));
                if (element == null)
                {
                    Assert.Fail();
                }
                else
                {
                    if (element.Displayed && element.Enabled)
                        element.Click();
                    else
                        Assert.Fail();
                }
            }
            catch (Exception e)
            {
            }
        }

        [Then(@"I can see Top Sellers list and select first item")]
        public void ThenICanSeeTopSellersListAndSelectFirstItem()
        {
            try
            {
                IList<IWebElement> elements = driver.FindElements(By.XPath("//div[@id='best-sellers_block_right']//ul//li"));
                if (elements.Count != 0)
                    elements[1].Click();
                else
                    Assert.Fail();
            }
            catch (Exception e)
            {
            }
        }

        [Then(@"I can see Add to Wishlist and I can add the item")]
        public void ThenICanSeeAddToWishlistAndICanAddTheItem()
        {
            try
            {
                IWebElement element = driver.FindElement(By.XPath("//a[@id='wishlist_button']"));
                if (element != null)
                {
                    if (element.Displayed && element.Enabled)
                        element.Click();
                    else
                        Assert.Fail();
                }
            }
            catch (Exception e)
            {
            }
        }

        [Then(@"Application should confirm")]
        public void ThenApplicationShouldConfirm()
        {
            IWebElement element = driver.FindElement(By.XPath("//p[@class='fancybox-error']"));
            if (element.Text == "Added to your wishlist.")
            {
                element = driver.FindElement(By.XPath("//a[@title='Close']"));
                element.Click();
            }

        }

        [Then(@"I confirm item is added in my wishlist page")]
        public void ThenIConfirmItemIsAddedInMyWishlistPage()
        {
            try
            {
                driver.Navigate().Back();
                IWebElement table = driver.FindElement(By.XPath("//div[@id = 'block-history']"));
                if (table != null)
                {
                    driver.FindElement(By.XPath("//div[@id = 'block-history']//td[5]//a")).Click();
                }
                else
                {
                    Assert.Fail();
                }
            }
            catch (Exception e)
            {
            }
        }

        [Then(@"I enter (.*) as input for email ID textbox")]
        public void ThenIEnterAsInputForEmailIDTextbox(string email)
        {
            bool sample = entertextbox(email, "//input[@id = 'email_create']");
            if (!sample)
                Assert.Fail();

        }

        [Then(@"I click create an account button")]
        public void ThenIClickCreateAnAccountButton()
        {
            driver.FindElement(By.XPath("//button[@id='SubmitCreate']")).Click();
        }

        [Then(@"I select (.*) radio button")]
        public void ThenISelectRadioButton(string title)
        {
            if (title == "Mr")
               driver.FindElement(By.XPath("//input[@id='id_gender1']")).Click();
            else
                driver.FindElement(By.XPath("//input[@id='id_gender2']")).Click();

        }

        [Then(@"I enter First name as (.*)")]
        public void ThenIEnterFirstNameAs(string first)
        {
            bool sample = entertextbox(first, "//input[@id='customer_firstname']");
            if (!sample)
                Assert.Fail();
        }

        [Then(@"I enter Last name as (.*)")]
        public void ThenIEnterLastNameAs(string last)
        {
            bool sample = entertextbox(last, "//input[@id='customer_lastname']");
            if (!sample)
                Assert.Fail();


        }

        [Then(@"I enter First name in under address (.*)")]
        public void ThenIEnterFirstNameInUnderAddress(string First)
        {
            bool sample = entertextbox(First, "//input[@id='firstname']");
            if (!sample)
                Assert.Fail();
        }

        [Then(@"I enter Last name under address (.*)")]
        public void ThenIEnterLastNameUnderAddress(string last)
        {
            bool sample = entertextbox(last, "//input[@id='lastname']");
            if (!sample)
                Assert.Fail();
        }

        [Then(@"I eneter address (.*)")]
        public void ThenIEneterAddress(string address)
        {
            bool sample = entertextbox(address, "//input[@id='address1']");
            if (!sample)
                Assert.Fail();
        }

        [Then(@"I enter city (.*)")]
        public void ThenIEnterCity(string city)
        {
            bool sample = entertextbox(city, "//input[@id='city']");
            if (!sample)
                Assert.Fail();
        }

        [Then(@"I enter state (.*)")]
        public void ThenIEnterState(string state)
        {
            bool sample = entertextbox(state, "//input[@id='city']");
            if (!sample)
                Assert.Fail();
        }

        [Then(@"I enter Password (.*)")]
        public void ThenIEnterPassword(string pass)
        {
            bool sample = entertextbox(pass, "//input[@id='passwd']");
            if (!sample)
                Assert.Fail();
        }


        [Then(@"I Select state (.*)")]
        public void ThenISelectState(string state)
        {
            bool sample = Selectbytext(state, "//select[@id='id_state']");
            if (!sample)
                Assert.Fail();
        }

        [Then(@"I enter Zipcode (.*)")]
        public void ThenIEnterZipcode(string zip)
        {
            bool sample = entertextbox(zip, "//input[@id='postcode']");
            if (!sample)
                Assert.Fail();
        }

        [Then(@"I select country (.*)")]
        public void ThenISelectCountry(string country)
        {
            bool sample = Selectbytext(country, "//select[@id='id_country']");
            if (!sample)
                Assert.Fail();
        }

        [Then(@"I enter mobile number (.*)")]
        public void ThenIEnterMobileNumber(string mobileNo)
        {
            bool sample = entertextbox(mobileNo, "//input[@id='phone_mobile']");
            if (!sample)
                Assert.Fail();
        }

        [Then(@"I enter address alias (.*)")]
        public void ThenIEnterAddressAlias(string alias)
        {
            bool sample = entertextbox(alias, "//input[@id='alias']");
            if (!sample)
                Assert.Fail();
        }

        public bool entertextbox(string input, string xpath)
        {
            try {
                IWebElement element = driver.FindElement(By.XPath(xpath));
                element.Clear();
                element.SendKeys(input);
                return true;

            }
            catch (Exception e)
            {
                return false;
            }
        }

        public bool Selectbytext(string input, string xpath)
        {
            try {
                IWebElement element = driver.FindElement(By.XPath(xpath));
                SelectElement select = new SelectElement(element);
                select.SelectByText(input);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

    










    }
}
